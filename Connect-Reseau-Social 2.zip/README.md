# Connect — Réseau social
Application web mobile de démonstration.

Fonctions incluses :
- fil d'actualité
- publication de messages
- likes
- commentaires (interface)
- profil
- messagerie (base)
- interface adaptée à l'iPhone

Important : cette version est un prototype front-end. Pour un vrai réseau social public, il faudra ajouter une base de données, des comptes utilisateurs, une authentification, des règles de sécurité, le stockage des photos et une modération.
