let posts=[
 {name:"Alex",avatar:"🧑",time:"Il y a 5 min",text:"Bienvenue sur Connect ! 🎉",likes:3},
 {name:"Lina",avatar:"👩",time:"Il y a 18 min",text:"Qui veut discuter ? 💬",likes:7}
];

function render(){
 const feed=document.getElementById("feed");
 feed.innerHTML=posts.map((p,i)=>`
 <article class="post">
  <div class="post-head"><div class="avatar">${p.avatar}</div><div><div class="name">${escapeHtml(p.name)}</div><div class="time">${p.time}</div></div></div>
  <p>${escapeHtml(p.text)}</p>
  <div class="actions"><button class="action" onclick="like(${i})">❤️ ${p.likes}</button><button class="action" onclick="comment(${i})">💬 Commenter</button></div>
 </article>`).join("");
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]))}
function publish(){
 const el=document.getElementById("postText"), text=el.value.trim();
 if(!text){alert("Écris quelque chose avant de publier.");return}
 posts.unshift({name:"Toi",avatar:"🙂",time:"À l'instant",text,likes:0});
 el.value=""; showFeed();
}
function like(i){posts[i].likes++;render()}
function comment(i){const c=prompt("Ton commentaire :");if(c) alert("Commentaire ajouté !")}
function showFeed(){location.hash="accueil"; document.getElementById("app").innerHTML=`
<section class="hero"><h1>Ton fil d'actualité 👋</h1><p>Découvre les publications de ta communauté.</p></section>
<section class="composer"><textarea id="postText" placeholder="Quoi de neuf ?"></textarea><button onclick="publish()">Publier</button></section><div id="feed"></div>`;render()}
function showCreate(){location.hash="publier";document.getElementById("app").innerHTML=`
<section class="panel"><h2>➕ Créer une publication</h2><textarea id="postText" placeholder="Partage quelque chose..." style="width:100%;min-height:150px;padding:12px;border:1px solid #d7dce5;border-radius:12px;font:inherit"></textarea><br><br><button class="action" onclick="publish()">Publier</button></section>`}
function showMessages(){location.hash="messages";document.getElementById("app").innerHTML=`<section class="panel"><h2>💬 Messages</h2><p>La messagerie sera disponible dans la prochaine version.</p><div class="empty">Aucune conversation pour le moment.</div></section>`}
function openProfile(){location.hash="profil";document.getElementById("app").innerHTML=`<section class="panel"><h2>🙂 Mon profil</h2><label>Nom</label><input value="Mon profil"><label>Présentation</label><input placeholder="Parle un peu de toi"><button class="profile-btn" onclick="alert('Profil enregistré !')">Enregistrer</button></section>`}
render();
