# Game App — version installable iPhone (PWA)

## Installation sur iPhone
1. Hébergez ce dossier sur une adresse HTTPS.
2. Ouvrez cette adresse dans Safari sur l'iPhone.
3. Touchez Partager → Sur l'écran d'accueil → Ajouter.
4. Lancez Game App depuis l'icône.

La PWA utilise localStorage pour les favoris et un service worker pour le cache.
Cette version est un prototype côté client : les comptes, données serveur et administration réelle nécessitent un backend.
